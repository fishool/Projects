package com.guli.sysuser.entity;

import lombok.Data;

/**
 * @author helen
 * @since 2019/3/2
 */
@Data
public class Sysuser {

	private String id;
	private String username;
	private String password;
}
