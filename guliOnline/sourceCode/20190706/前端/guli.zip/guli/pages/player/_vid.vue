<template>
  <div>

    <!-- 阿里云视频播放器样式 -->
    <link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/2.8.1/skins/default/aliplayer-min.css" >
    <!-- 启用私有加密的防调式：生产环境使用 -->
    <script src="https://g.alicdn.com/de/prismplayer/2.8.0/hls/aliplayer-vod-anti-min.js" />
    <!-- 阿里云视频播放器脚本 -->
    <script charset="utf-8" type="text/javascript" src="https://g.alicdn.com/de/prismplayer/2.8.1/aliplayer-min.js" />

    <!-- 阿里云播放器组件库 -->
    <script type="text/javascript" charset="utf-8" src="https://player.alicdn.com/aliplayer/presentation/js/aliplayercomponents.min.js"/>

    <div id="J_prismPlayer" class="prism-player"/>
  </div>
</template>

<script>
import vod from '@/api/vod'

export default {
  layout: 'video', // 指定播放器模板
  asyncData({ params, error }) {
    return vod.getPlayAuth(params.vid).then(response => {
      return {
        palyAuth: response.data.data.playAuth,
        vid: params.vid
      }
    })
  },

  created() {
    // 内存已经初始化成功，但是页面还没有被渲染
  },
  mounted() {
    // 内存已经初始化成功，页面已经被渲染

    /* 关闭广告的自定义事件, 可自行修改代码从而满足不同的功能, 参数为视频广告组件本身 */
    var videoAdClose = function(videoAd) {
    /* 调用视频广告组件的暂停事件来暂停广告 */
      videoAd.pauseVideoAd()
      var result = confirm('确定开通会员关闭广告吗？')
      if (result) {
      /* 调用视频广告组件关闭事件来关闭广告 */
        videoAd.closeVideoAd()
      } else {
      /* 调用视频广告组件的播放事件来播放广告 */
        videoAd.playVideoAd()
      }
    }

    /* 弹幕组件集成了 CommentCoreLibrary 框架, 更多 Api 请查看文档 https://github.com/jabbany/CommentCoreLibrary/ */
    var danmukuList = [{
      'mode': 1,
      'text': '哈哈',
      'stime': 1000,
      'size': 25,
      'color': 0xffffff
    }, {
      'mode': 1,
      'text': '前方高能',
      'stime': 2000,
      'size': 25,
      'color': 0xff0000
    }, {
      'mode': 1,
      'text': '灵魂歌手',
      'stime': 30000,
      'size': 25,
      'color': 0xff0000
    }, {
      'mode': 1,
      'text': '这是弹幕2',
      'stime': 4000,
      'size': 25,
      'color': 0x00c1de
    }, {
      'mode': 1,
      'text': '神测试',
      'stime': 5000,
      'size': 25,
      'color': 0x00c1de
    }, {
      'mode': 1,
      'text': '顺手一划',
      'stime': 10000,
      'size': 25,
      'color': 0x00c1de
    }, {
      'mode': 1,
      'text': '哈哈',
      'stime': 1000,
      'size': 25,
      'color': 0xffffff
    }]

    // 创建播放器
    /* eslint-disable no-undef */
    var player = new Aliplayer({
      id: 'J_prismPlayer',
      width: '100%',
      height: '500px',
      autoplay: false,
      cover: 'http://liveroom-img.oss-cn-qingdao.aliyuncs.com/logo.png',

      // 加密视频需要通过视频id和授权码进行播放
      encryptType: '1', // 如果播放加密视频，则需设置encryptType=1，非加密视频无需设置此项
      vid: this.vid,
      playauth: this.palyAuth,

      components: [{
        name: 'BulletScreenComponent', // 跑马灯组件
        type: AliPlayerComponent.BulletScreenComponent,
        /** 跑马灯组件三个参数 text, style, bulletPosition
       * text: 跑马灯文字内容
       * style: 跑马灯样式
       * bulletPosition: 跑马灯位置, 可选的值为 'top' (顶部), 'bottom' (底部), 'random' (随机), 不传值默认为 'random'
       */
        args: ['helen，欢迎来到谷粒学院', { fontSize: '16px', color: '#00c1de' }, 'random']
      },

      {
        name: 'VideoADComponent', // 视频广告组件
        type: AliPlayerComponent.VideoADComponent,
        /* 视频广告四个参数 adVideoSource, adLink, adCloseFunction, closeText
       * adVideoSource {@String 广告视频的视频地址 必须参数}
       * adLink {@String 广告视频的链接地址 必须参数}
       * adCloseFunction {@Function 关闭广告的点击事件处理函数, 可选参数, 不传则默认关闭广告视频}
       * closeText {@String 关闭广告的文字内容, 可选参数, 不传则默认为 '关闭广告'}
       */
        args: ['http://player.alicdn.com/ad/citybrain.mp4', 'http://atguigu.com', videoAdClose, '会员关闭广告']
      },

      {
        name: 'AliplayerDanmuComponent', // 弹幕
        type: AliPlayerComponent.AliplayerDanmuComponent,
        args: [danmukuList]
      }

      ],

      'extraInfo': {
        'crossOrigin': 'anonymous'
      },
      'skinLayout': [
        { 'name': 'bigPlayButton', 'align': 'blabs', 'x': 30, 'y': 80 },
        { 'name': 'H5Loading', 'align': 'cc' },
        { 'name': 'errorDisplay', 'align': 'tlabs', 'x': 0, 'y': 0 },
        { 'name': 'infoDisplay' },
        { 'name': 'tooltip', 'align': 'blabs', 'x': 0, 'y': 56 },
        { 'name': 'thumbnail' },
        {
          'name': 'controlBar', 'align': 'blabs', 'x': 0, 'y': 0,
          'children': [
            { 'name': 'progress', 'align': 'blabs', 'x': 0, 'y': 44 },
            { 'name': 'playButton', 'align': 'tl', 'x': 15, 'y': 12 },
            { 'name': 'timeDisplay', 'align': 'tl', 'x': 10, 'y': 7 },
            { 'name': 'fullScreenButton', 'align': 'tr', 'x': 10, 'y': 12 },
            { 'name': 'subtitle', 'align': 'tr', 'x': 15, 'y': 12 },
            { 'name': 'setting', 'align': 'tr', 'x': 15, 'y': 12 },
            { 'name': 'volume', 'align': 'tr', 'x': 5, 'y': 10 },
            { 'name': 'snapshot', 'align': 'tr', 'x': 10, 'y': 12 }
          ]
        }
      ]

    }, function() {
      console.log('播放器创建成功')
    })

    /* h5截图按钮, 截图成功回调 */
    player.on('snapshoted', function(data) {
      var pictureData = data.paramData.base64
      var downloadElement = document.createElement('a')
      downloadElement.setAttribute('href', pictureData)
      var fileName = 'Aliplayer' + Date.now() + '.png'
      downloadElement.setAttribute('download', fileName)
      downloadElement.click()
      pictureData = null
    })
  }
}
</script>

