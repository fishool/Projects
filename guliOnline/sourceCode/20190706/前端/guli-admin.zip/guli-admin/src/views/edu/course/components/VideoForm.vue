<template>
  <!-- 添加和修改课时表单 -->
  <el-dialog :visible.sync="dialogVisible" title="添加课时">
    <el-form :model="video" label-width="120px">
      <el-form-item label="课时标题">
        <el-input v-model="video.title"/>
      </el-form-item>
      <el-form-item label="课时排序">
        <el-input-number v-model="video.sort" :min="0" controls-position="right"/>
      </el-form-item>
      <el-form-item label="是否免费">
        <el-radio-group v-model="video.free">
          <el-radio :label="true">免费</el-radio>
          <el-radio :label="false">默认</el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item label="上传视频" label-width="120px" >

        <el-upload
          ref="upload"
          :on-change="fileChange"
          :on-exceed="handleUploadExceed"
          :before-remove="beforeVodRemove"
          :on-remove="handleVodRemove"
          :file-list="fileList"
          :limit="1"
          :auto-upload="false"
          class="upload-demo"
          action="">
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          <el-tooltip placement="right-end">
            <div slot="content">最大支持1G，<br>
              支持3GP、ASF、AVI、DAT、DV、FLV、F4V、<br>
              GIF、M2T、M4V、MJ2、MJPEG、MKV、MOV、MP4、<br>
              MPE、MPG、MPEG、MTS、OGG、QT、RM、RMVB、<br>
              SWF、TS、VOB、WMV、WEBM 等视频格式上传</div>
            <i class="el-icon-question"/>
          </el-tooltip>
          <el-button
            :disabled="uploadDisabled"
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="authUpload">开始上传</el-button>
          <label class="status"><span>{{ statusText }}</span></label>
          <span class="progress"><i id="auth-progress">{{ authProgress }}</i></span>
        </el-upload>

      </el-form-item>

    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="saveOrUpdate">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import video from '@/api/edu/video'
import vod from '@/api/edu/vod'

export default {

  // 父组件向子组件传值
  props: {
    courseId: {
      type: String,
      default: null
    }
  },

  data() {
    return {
      dialogVisible: false,
      video: {// 课时对象
        chapterId: '',
        title: '',
        sort: 0,
        free: false,
        videoSourceId: '',
        videoOriginalName: ''
      },

      fileList: [], // 上传的视频文件列表
      BASE_API: process.env.BASE_API, // 接口api地址

      // javascript视频上传sdk相关的数据
      timeout: '', // 响应的超时时间
      partSize: '', // 分片大小默认1M，不能小于100K
      parallel: '', // 并行上传分片个数，默认5
      retryCount: '', // 网络原因失败时，重新上传次数，默认为3
      retryDuration: '', // 网络原因失败时，重新上传间隔时间，默认为2秒
      region: 'cn-shanghai', // 上传到点播的地域， 默认值为'cn-shanghai',//eu-central-1,ap-southeast-1
      userId: '1506273167771201', // 阿里账号ID ，值的来源https://help.aliyun.com/knowledge_detail/37196.html

      file: null, // 被上传文件的元数据信息
      authProgress: null, // 文件上传进度的百分比
      uploadDisabled: true, // 上传文件按钮的状态
      uploader: null, // javascript sdk的文件上传对象
      statusText: '' // 当前文件的上传状态
    }
  },

  methods: {
    open(chapterId, videoId) {
      this.dialogVisible = true
      this.video.chapterId = chapterId
      if (videoId) {
        video.getById(videoId).then(response => {
          this.video = response.data.item
          // 填充上传文件列表
          if (this.video.videoOriginalName) {
            this.fileList = [{ 'name': this.video.videoOriginalName }]
          }
        })
      }
    },

    close() {
      this.dialogVisible = false
      // 重置表单
      this.resetForm()
    },

    saveOrUpdate() {
      if (!this.video.id) {
        this.save()
      } else {
        this.update()
      }
    },

    save() {
      this.video.courseId = this.courseId
      console.log(this.video)
      video.save(this.video).then(response => {
        this.$message({
          type: 'success',
          message: '保存成功!'
        })
        // 关闭组件
        this.close()
        // 调用父组件监听函数
        this.$emit('onSaveSuccess')
      })
    },

    update() {
      console.log(this.video)
      video.updateById(this.video).then(response => {
        this.$message({
          type: 'success',
          message: '修改成功!'
        })
        // 关闭组件
        this.close()
        // 调用父组件监听函数
        this.$emit('onSaveSuccess')
      })
    },

    resetForm() {
      this.video.id = null
      this.video.title = ''
      this.video.sort = 0
      this.video.chapterId = ''
      this.video.free = false
      this.video.videoSourceId = ''
      this.video.videoOriginalName = ''

      this.fileList = []

      this.file = null
      this.authProgress = null
      this.uploadDisabled = true
      this.uploader = null
      this.statusText = ''
    },

    // 上传成功的回调函数
    // handleVodUploadSuccess(response, file) {
    //   this.video.videoSourceId = response.data.videoId
    //   this.video.videoOriginalName = file.name
    // },

    // 超出视频上传个数限制的回调
    handleUploadExceed() {
      this.$message.warning('想要重新上传视频，请先删除已上传的视频文件')
    },

    //  :before-remove="beforeVodRemove"
    //     :on-remove="handleVodRemove"
    // 删除确认
    beforeVodRemove(file) {
      return this.$confirm('您是否确定要删除' + file.name + '?')
    },

    // 删除时回调
    handleVodRemove() {
      vod.removeById(this.video.videoSourceId).then(response => {
        this.video.videoSourceId = ''
        this.video.videoOriginalName = ''
        this.fileList = []
        video.updateById(this.video)

        this.$message({
          type: 'success',
          message: response.message
        })
      })
    },

    // javascript sdk上传选择文件事件
    fileChange(file, fileList) {
      console.log('fileChange')
      this.file = file.raw

      if (this.uploader) {
        this.uploader.stopUpload()
        this.authProgress = 0
        this.statusText = ''
      }

      // 创建javascript sdk的文件上传对象
      this.uploader = this.createUploader()
      var userData = '{"Vod":{}}'
      this.uploader.addFile(this.file, null, null, null, userData)
    },

    // 创建阿里云播放器组件
    createUploader() {
      console.log('createUploader')
      const self = this
      /* eslint-disable no-undef */
      const uploader = new AliyunUpload.Vod({
        // 阿里账号ID ，值的来源https://help.aliyun.com/knowledge_detail/37196.html
        userId: self.userId,
        // 上传到点播的地域， 默认值为'cn-shanghai',//eu-central-1,ap-southeast-1
        region: self.region,
        // 超时时间
        timeout: self.timeout || 60000,
        // 分片大小默认1M，不能小于100K
        partSize: self.partSize || 1048576,
        // 并行上传分片个数，默认5
        parallel: self.parallel || 5,
        // 网络原因失败时，重新上传次数，默认为3
        retryCount: self.retryCount || 3,
        // 网络原因失败时，重新上传间隔时间，默认为2秒
        retryDuration: self.retryDuration || 2,
        // 添加文件成功
        'addFileSuccess': function(uploadInfo) {
          console.log('添加文件成功')
          console.log(uploadInfo)
          self.uploadDisabled = false
          self.statusText = '添加文件成功，等待上传......'
          console.log('文件名：' + uploadInfo.file.name)
        },

        // 开始上传
        'onUploadstarted': function(uploadInfo) {
          console.log('开始上传')
          console.log(uploadInfo)
          console.log('获取上传地址和凭证')

          self.uploadDisabled = true
          self.statusText = '文件开始上传......'

          const fileName = uploadInfo.file.name
          const title = fileName.substring(0, fileName.lastIndexOf('.'))
          vod.getUploadAuthAndAddress(title, fileName).then(response => {
            console.log(response)
            const uploadAuth = response.data.response.uploadAuth
            const uploadAddress = response.data.response.uploadAddress
            const videoId = response.data.response.videoId
            console.log('文件开始上传......')
            uploader.setUploadAuthAndAddress(uploadInfo, uploadAuth, uploadAddress, videoId)
          })
        },
        // 文件上传成功
        'onUploadSucceed': function(uploadInfo) {
          console.log('文件上传成功')
          console.log(uploadInfo)

          self.uploadDisabled = false
          self.statusText = '文件上传成功!'

          const fileName = uploadInfo.file.name
          const title = fileName.substring(0, fileName.lastIndexOf('.'))

          self.video.videoSourceId = uploadInfo.videoId
          self.video.videoOriginalName = title
        },
        // 文件上传失败
        'onUploadFailed': function(uploadInfo, code, message) {
          console.log('文件上传失败')

          self.uploadDisabled = false
          self.statusText = '文件上传失败!'
        },
        // 文件上传进度，单位：字节
        'onUploadProgress': function(uploadInfo, totalSize, loadedPercent) {
          console.log('文件上传进度')
          console.log('totalSize = ' + totalSize)
          console.log('loadedPercent = ' + loadedPercent)
          const percent = Math.ceil(loadedPercent * 100)
          self.authProgress = percent + '%'
          console.log('percent = ' + self.authProgress)
          self.statusText = '文件上传中......'
        },
        // 上传凭证超时
        'onUploadTokenExpired': function(uploadInfo) {
          console.log('上传凭证超时')

          self.statusText = '上传文件超时......'

          // 刷新上传凭证
          vod.refreshUploadAuthAndAddress(uploadInfo.videoId).then(response => {
            const uploadAuth = response.data.response.uploadAuth
            // 上传凭证失效后恢复上传
            uploader.resumeUploadWithAuth(uploadAuth)
          })
        },
        // 全部文件上传结束
        'onUploadEnd': function(uploadInfo) {
          console.log('全部文件上传结束')
          self.statusText = '全部文件上传结束!'
        }
      })

      return uploader
    },

    // 使用javascript sdk执行上传
    authUpload() {
      if (this.uploader != null) {
        this.uploader.startUpload()
      }
    }

  }
}
</script>
