<template>
  <!-- 添加和修改章节表单 -->
  <el-dialog
    :visible.sync="dialogVisible"
    title="添加章节"
    @close="close"
  >
    <el-form :model="chapter" label-width="120px">
      <el-form-item label="章节标题">
        <el-input v-model="chapter.title"/>
      </el-form-item>
      <el-form-item label="章节排序">
        <el-input-number v-model="chapter.sort" :min="0" controls-position="right"/>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="saveOrUpdate">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import chapter from '@/api/edu/chapter'

export default {

  // 组件的属性定义：
  // 作用：父组件向租组件传值
  props: {
    courseId: {
      type: String,
      default: null
    }
  },

  data() {
    return {
      dialogVisible: false, // 是否显示 dialog
      chapter: { // 章节数据
        title: '',
        sort: 0
      }
    }
  },

  methods: {

    open(chapterId) {
      this.dialogVisible = true

      // undefined、null、''、false、0
      // 如果是编辑章节，name需要根据chapterId查找章节信息
      if (chapterId) {
        chapter.getById(chapterId).then(response => {
          this.chapter = response.data.item
        })
      }
    },

    close() {
      console.log('close......')
      this.dialogVisible = false
      this.resetForm()
    },

    saveOrUpdate() {
      if (!this.chapter.id) {
        this.save()
      } else {
        this.update()
      }
    },

    save() {
      this.chapter.courseId = this.courseId
      chapter.save(this.chapter).then(response => {
        this.$message({
          type: 'success',
          message: '保存成功!'
        })
        // 关闭表单
        this.close()
        // 触发子组件的事件，当事件发生时，可以调用父组件的方法
        this.$emit('onSaveSuccess')
      })
    },

    update() {
      chapter.updateById(this.chapter).then(response => {
        this.$message({
          type: 'success',
          message: '修改成功!'
        })
        // 关闭表单
        this.close()
        // 触发子组件的事件，当事件发生时，可以调用父组件的方法
        this.$emit('onSaveSuccess')
      })
    },

    resetForm() {
      console.log('resetform......')
      this.chapter.id = null
      this.chapter.title = ''
      this.chapter.sort = 0
    }
  }
}
</script>

