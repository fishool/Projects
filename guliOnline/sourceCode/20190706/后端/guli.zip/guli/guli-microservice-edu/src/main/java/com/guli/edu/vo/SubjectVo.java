package com.guli.edu.vo;

/**
 * @author helen
 * @since 2019/6/29
 */

import lombok.Data;
@Data
public class SubjectVo {

	private String id;
	private String title;
}
