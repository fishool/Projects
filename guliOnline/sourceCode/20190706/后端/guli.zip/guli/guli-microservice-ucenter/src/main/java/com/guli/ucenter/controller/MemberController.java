package com.guli.ucenter.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2019-07-01
 */
@RestController
@RequestMapping("/ucenter/member")
public class MemberController {

}

