package com.atguigu.jwt;

import com.atguigu.jwt.entity.Member;
import com.atguigu.jwt.util.JwtUtils;
import io.jsonwebtoken.Claims;
import org.junit.Test;

/**
 * @author helen
 * @since 2019/7/6
 */
public class JwtTest {

	@Test
	public void testGenerateJWT(){

		Member member = new Member();
		member.setId("10000");
		member.setNickname("Helen");
		member.setAvatar("1.png");
		String jwt = JwtUtils.generateJWT(member);
		System.out.println(jwt);
	}


	@Test
	public void testCheckJWT(){

		Claims claims = JwtUtils.checkJWT("生成的jwt字符串");

		String nickname = (String)claims.get("nickname");
		String avatar = (String)claims.get("avatar");

		System.out.println(nickname);
		System.out.println(avatar);
	}
}
