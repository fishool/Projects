package com.atguigu.jwt.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 会员表
 * </p>
 *
 * @author Helen
 * @since 2019-07-01
 */
@Data
public class Member implements Serializable {

    private static final long serialVersionUID = 1L;


    private String id;

    private String openid;

    private String mobile;

    private String password;

    private String nickname;

    private String avatar;

}
